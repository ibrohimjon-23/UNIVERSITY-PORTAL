import { describe, expect, it } from "vitest";
import { encodeAttendanceQr, decodeAttendanceQr } from "@/lib/qr";

describe("attendance QR payload encode/decode", () => {
  it("round-trips a valid payload", () => {
    const payload = { sessionId: "11111111-1111-1111-1111-111111111111", token: "abc123token" };
    const decoded = decodeAttendanceQr(encodeAttendanceQr(payload));
    expect(decoded).toEqual(payload);
  });

  it("rejects malformed JSON", () => {
    expect(decodeAttendanceQr("not-json")).toBeNull();
  });

  it("rejects JSON missing required fields", () => {
    expect(decodeAttendanceQr(JSON.stringify({ sessionId: "abc" }))).toBeNull();
    expect(decodeAttendanceQr(JSON.stringify({ token: "abc" }))).toBeNull();
    expect(decodeAttendanceQr(JSON.stringify({}))).toBeNull();
  });

  it("rejects a forged payload with the wrong field types", () => {
    expect(decodeAttendanceQr(JSON.stringify({ sessionId: 123, token: "abc" }))).toBeNull();
  });
});
