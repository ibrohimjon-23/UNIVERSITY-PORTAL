import { describe, expect, it } from "vitest";
import { haversineMeters } from "@/lib/geo";

describe("haversineMeters", () => {
  it("returns ~0 for identical coordinates", () => {
    expect(haversineMeters(40.785444, 72.352389, 40.785444, 72.352389)).toBeCloseTo(0, 3);
  });

  it("matches a known distance between two real-world points within 1%", () => {
    // London (51.5074, -0.1278) to Paris (48.8566, 2.3522) is ~343.5km.
    const distance = haversineMeters(51.5074, -0.1278, 48.8566, 2.3522);
    expect(distance).toBeGreaterThan(340_000);
    expect(distance).toBeLessThan(347_000);
  });

  it("is symmetric regardless of point order", () => {
    const a = haversineMeters(40.785444, 72.352389, 40.7861, 72.353);
    const b = haversineMeters(40.7861, 72.353, 40.785444, 72.352389);
    expect(a).toBeCloseTo(b, 6);
  });

  it("stays inside a 200m attendance radius for a small offset", () => {
    // ~0.0009 degrees latitude is roughly 100m.
    const distance = haversineMeters(40.785444, 72.352389, 40.786344, 72.352389);
    expect(distance).toBeLessThan(200);
  });

  it("is outside a 200m attendance radius for a large offset", () => {
    const distance = haversineMeters(40.785444, 72.352389, 40.795444, 72.352389);
    expect(distance).toBeGreaterThan(200);
  });
});
