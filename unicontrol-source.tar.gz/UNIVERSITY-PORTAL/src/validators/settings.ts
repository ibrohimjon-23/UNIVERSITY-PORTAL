import { z } from "zod";

export const settingsSchema = z.object({
  university_name: z.string().trim().min(2, "University name is required").max(200),
  latitude: z.coerce.number().min(-90).max(90),
  longitude: z.coerce.number().min(-180).max(180),
  attendance_radius_m: z.coerce.number().int().min(10).max(5000),
  timezone: z.string().trim().min(2).max(64),
  qr_expiry_seconds: z.coerce.number().int().min(15).max(300),
  late_after_minutes: z.coerce.number().int().min(0).max(120),
});

export type SettingsInput = z.infer<typeof settingsSchema>;
