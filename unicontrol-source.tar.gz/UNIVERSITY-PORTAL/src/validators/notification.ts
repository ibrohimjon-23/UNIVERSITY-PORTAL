import { z } from "zod";

export const notificationSchema = z
  .object({
    title: z.string().trim().min(2, "Title is required").max(200),
    message: z.string().trim().min(2, "Message is required").max(2000),
    type: z.enum(["info", "success", "warning", "urgent"]).default("info"),
    target_type: z.enum(["everyone", "all_leaders", "all_students", "group", "student"]),
    target_id: z.string().uuid().optional().or(z.literal("")).nullable(),
  })
  .refine((data) => (["group", "student"].includes(data.target_type) ? !!data.target_id : true), {
    message: "Select a target",
    path: ["target_id"],
  });

export type NotificationInput = z.infer<typeof notificationSchema>;
