import { z } from "zod";

const timeField = z.string().regex(/^([01]\d|2[0-3]):[0-5]\d$/, "Use HH:MM format");

export const scheduleSchema = z
  .object({
    group_id: z.string().uuid("Select a group"),
    subject_id: z.string().uuid("Select a subject"),
    teacher_id: z.string().uuid().optional().or(z.literal("")).nullable(),
    room: z.string().trim().min(1, "Room is required").max(32),
    day_of_week: z.coerce.number().int().min(0).max(6),
    start_time: timeField,
    end_time: timeField,
  })
  .refine((data) => data.end_time > data.start_time, {
    message: "End time must be after start time",
    path: ["end_time"],
  });

export type ScheduleInput = z.infer<typeof scheduleSchema>;

export const subjectSchema = z.object({
  name: z.string().trim().min(2, "Subject name is required").max(128),
  code: z.string().trim().min(1, "Code is required").max(16),
});

export type SubjectInput = z.infer<typeof subjectSchema>;

export const teacherSchema = z.object({
  first_name: z.string().trim().min(1, "First name is required").max(64),
  last_name: z.string().trim().min(1, "Last name is required").max(64),
  phone: z.string().trim().max(20).optional().or(z.literal("")),
  email: z.string().trim().email().optional().or(z.literal("")),
});

export type TeacherInput = z.infer<typeof teacherSchema>;
