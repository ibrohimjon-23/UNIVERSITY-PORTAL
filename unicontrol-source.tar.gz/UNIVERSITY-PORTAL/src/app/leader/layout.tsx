import { requireRole } from "@/lib/auth";
import { AppShell } from "@/components/layout/app-shell";

export default async function LeaderLayout({ children }: { children: React.ReactNode }) {
  const profile = await requireRole("leader");
  return <AppShell profile={profile}>{children}</AppShell>;
}
