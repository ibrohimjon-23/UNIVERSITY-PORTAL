import type { Metadata } from "next";
import { UserCog } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { EmptyState } from "@/components/shared/empty-state";
import { QuerySearch } from "@/components/shared/query-search";
import { QueryPagination } from "@/components/shared/query-pagination";
import { LeaderFormDialog } from "@/features/leaders/leader-form-dialog";
import { LeaderRowActions } from "@/features/leaders/leader-row-actions";
import { listLeaders } from "@/features/leaders/queries";
import { listAllGroups } from "@/features/groups/queries";

export const metadata: Metadata = { title: "Leaders" };

interface PageProps {
  searchParams: Promise<{ q?: string; page?: string }>;
}

export default async function AdminLeadersPage({ searchParams }: PageProps) {
  const params = await searchParams;
  const page = Number(params.page ?? 1);

  const [{ rows, total, pageSize }, groups] = await Promise.all([
    listLeaders({ query: params.q, page }),
    listAllGroups(),
  ]);

  return (
    <div className="space-y-6">
      <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">Leaders</h1>
          <p className="text-sm text-muted-foreground">Group leaders and class representatives.</p>
        </div>
        <LeaderFormDialog groups={groups} />
      </div>

      <QuerySearch placeholder="Search by name or username..." />

      <Card>
        {rows.length === 0 ? (
          <EmptyState icon={UserCog} title="No leaders found" description="Create a leader account to get started." />
        ) : (
          <>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Username</TableHead>
                  <TableHead>Group</TableHead>
                  <TableHead>Phone</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {rows.map((leader) => (
                  <TableRow key={leader.id}>
                    <TableCell className="font-medium">
                      {leader.first_name} {leader.last_name}
                    </TableCell>
                    <TableCell>@{leader.username}</TableCell>
                    <TableCell>
                      {leader.led_group ? leader.led_group.group_name : <Badge variant="outline">Unassigned</Badge>}
                    </TableCell>
                    <TableCell>{leader.phone ?? "—"}</TableCell>
                    <TableCell>
                      <Badge variant={leader.is_active ? "success" : "secondary"}>
                        {leader.is_active ? "Active" : "Inactive"}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <LeaderRowActions leader={leader} groups={groups} />
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
            <QueryPagination page={page} pageSize={pageSize} total={total} />
          </>
        )}
      </Card>
    </div>
  );
}
