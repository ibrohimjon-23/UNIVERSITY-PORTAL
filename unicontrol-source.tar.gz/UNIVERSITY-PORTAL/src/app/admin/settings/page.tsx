import type { Metadata } from "next";
import { getUniversitySettings } from "@/features/settings/queries";
import { SettingsForm } from "./settings-form";

export const metadata: Metadata = { title: "Settings" };

export default async function AdminSettingsPage() {
  const settings = await getUniversitySettings();

  return (
    <div className="max-w-2xl space-y-6">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight">Settings</h1>
        <p className="text-sm text-muted-foreground">University-wide configuration for attendance and identity.</p>
      </div>
      <SettingsForm settings={settings} />
    </div>
  );
}
