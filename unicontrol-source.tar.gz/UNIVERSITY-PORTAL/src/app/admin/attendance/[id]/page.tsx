import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { getSessionDetail } from "@/features/attendance/queries";
import { QrDisplay } from "@/features/attendance/qr-display";
import { SessionDetailClient } from "@/features/attendance/session-detail-client";
import { createClient } from "@/lib/supabase/server";

export const metadata: Metadata = { title: "Attendance session" };

export default async function AdminAttendanceSessionPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const { session, records, groupStudents } = await getSessionDetail(id);
  if (!session) notFound();

  const supabase = await createClient();
  const [{ data: group }, { data: subject }] = await Promise.all([
    supabase.from("groups").select("group_name").eq("id", session.group_id).maybeSingle(),
    supabase.from("subjects").select("name").eq("id", session.subject_id).maybeSingle(),
  ]);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight">
          {group?.group_name} · {subject?.name}
        </h1>
        <p className="text-sm text-muted-foreground">{session.session_date}</p>
      </div>

      {session.status === "active" ? (
        <div className="flex justify-center">
          <QrDisplay sessionId={session.id} initialToken={session.qr_token} initialExpiresAt={session.qr_expires_at} />
        </div>
      ) : null}

      <SessionDetailClient session={session} records={records} groupStudents={groupStudents} />
    </div>
  );
}
