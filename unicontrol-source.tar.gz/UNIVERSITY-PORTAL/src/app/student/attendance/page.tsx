import type { Metadata } from "next";
import { requireRole } from "@/lib/auth";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { EmptyState } from "@/components/shared/empty-state";
import { StatCard } from "@/components/shared/stat-card";
import { StudentCheckin } from "@/features/attendance/student-checkin";
import { getActiveSessionForGroup, listStudentAttendance, getStudentAttendanceSummary } from "@/features/attendance/queries";
import { getUniversitySettings } from "@/features/settings/queries";
import { CalendarCheck, CheckCircle2, Clock, XCircle } from "lucide-react";
import { createClient } from "@/lib/supabase/server";

export const metadata: Metadata = { title: "Attendance" };

const STATUS_VARIANT = {
  present: "success",
  late: "warning",
  absent: "destructive",
  excused: "secondary",
} as const;

export default async function StudentAttendancePage() {
  const student = await requireRole("student");
  const settings = await getUniversitySettings();

  const activeSession = student.group_id ? await getActiveSessionForGroup(student.group_id) : null;
  let subjectName: string | null = null;
  if (activeSession) {
    const supabase = await createClient();
    const { data } = await supabase.from("subjects").select("name").eq("id", activeSession.subject_id).maybeSingle();
    subjectName = data?.name ?? null;
  }

  const [summary, history] = await Promise.all([
    getStudentAttendanceSummary(student.id),
    listStudentAttendance(student.id, 1, 15),
  ]);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight">Attendance</h1>
        <p className="text-sm text-muted-foreground">Check in for class and review your attendance history.</p>
      </div>

      <StudentCheckin
        activeSessionId={activeSession?.id ?? null}
        subjectName={subjectName}
        universityLat={settings.latitude}
        universityLng={settings.longitude}
        radiusMeters={settings.attendance_radius_m}
      />

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label="Present" value={summary.present} icon={CheckCircle2} tone="success" />
        <StatCard label="Late" value={summary.late} icon={Clock} tone="warning" />
        <StatCard label="Absent" value={summary.absent} icon={XCircle} tone="destructive" />
        <StatCard label="Excused" value={summary.excused} icon={CalendarCheck} />
      </div>

      <Card>
        {history.rows.length === 0 ? (
          <EmptyState icon={CalendarCheck} title="No attendance history yet" />
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Date</TableHead>
                <TableHead>Subject</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Distance</TableHead>
                <TableHead>Checked in</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {history.rows.map((r) => (
                <TableRow key={r.id}>
                  <TableCell>{r.session?.session_date ?? "—"}</TableCell>
                  <TableCell>{r.subject?.name ?? "—"}</TableCell>
                  <TableCell>
                    <Badge variant={STATUS_VARIANT[r.status]} className="capitalize">
                      {r.status}
                    </Badge>
                  </TableCell>
                  <TableCell>{r.distance_from_university != null ? `${Math.round(r.distance_from_university)}m` : "—"}</TableCell>
                  <TableCell>{new Date(r.checked_at).toLocaleString()}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </Card>
    </div>
  );
}
