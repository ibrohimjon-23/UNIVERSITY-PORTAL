import type { Metadata } from "next";
import Link from "next/link";
import { CalendarDays, CheckCircle2, Clock, FileText, Layers, MapPin } from "lucide-react";
import { requireRole } from "@/lib/auth";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { StatCard } from "@/components/shared/stat-card";
import { EmptyState } from "@/components/shared/empty-state";
import { getStudentAttendanceSummary, getActiveSessionForGroup } from "@/features/attendance/queries";
import { listSchedulesForGroup } from "@/features/schedules/queries";
import { listAssignmentsForStudent } from "@/features/assignments/queries";
import { formatTime } from "@/lib/utils";

export const metadata: Metadata = { title: "Dashboard" };

export default async function StudentDashboardPage() {
  const student = await requireRole("student");

  if (!student.group_id) {
    return <EmptyState icon={Layers} title="No group assigned" description="Contact an administrator to be assigned to a group." />;
  }

  const today = new Date().getDay();
  const [summary, schedules, assignments, activeSession] = await Promise.all([
    getStudentAttendanceSummary(student.id),
    listSchedulesForGroup(student.group_id),
    listAssignmentsForStudent(student.id, student.group_id),
    getActiveSessionForGroup(student.group_id),
  ]);

  const todayClasses = schedules.filter((s) => s.day_of_week === today).sort((a, b) => a.start_time.localeCompare(b.start_time));
  const upcoming = assignments.filter((a) => !a.mySubmission).slice(0, 3);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight">Welcome back, {student.first_name}</h1>
        <p className="text-sm text-muted-foreground">Here&apos;s what&apos;s happening today.</p>
      </div>

      {activeSession ? (
        <Card className="border-primary/40 bg-primary/5">
          <CardContent className="flex items-center justify-between p-4">
            <div className="flex items-center gap-3">
              <MapPin className="h-5 w-5 text-primary" />
              <p className="text-sm font-medium">An attendance session is active for your group right now.</p>
            </div>
            <Link href="/student/attendance" className="text-sm font-medium text-primary underline">
              Check in
            </Link>
          </CardContent>
        </Card>
      ) : null}

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label="Present" value={summary.present} icon={CheckCircle2} tone="success" />
        <StatCard label="Late" value={summary.late} icon={Clock} tone="warning" />
        <StatCard label="Absent" value={summary.absent} icon={CheckCircle2} tone="destructive" />
        <StatCard label="Total records" value={summary.total} icon={CalendarDays} />
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Today&apos;s classes</CardTitle>
          </CardHeader>
          <CardContent>
            {todayClasses.length === 0 ? (
              <p className="text-sm text-muted-foreground">No classes scheduled today.</p>
            ) : (
              <div className="space-y-3">
                {todayClasses.map((s) => (
                  <div key={s.id} className="flex items-center justify-between rounded-md border p-3">
                    <div>
                      <p className="text-sm font-medium">{s.subject?.name}</p>
                      <p className="text-xs text-muted-foreground">Room {s.room}</p>
                    </div>
                    <p className="text-sm text-muted-foreground">
                      {formatTime(s.start_time)} – {formatTime(s.end_time)}
                    </p>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">Upcoming assignments</CardTitle>
          </CardHeader>
          <CardContent>
            {upcoming.length === 0 ? (
              <p className="text-sm text-muted-foreground">Nothing due right now.</p>
            ) : (
              <div className="space-y-3">
                {upcoming.map((a) => (
                  <div key={a.id} className="flex items-center justify-between rounded-md border p-3">
                    <div className="flex items-center gap-2">
                      <FileText className="h-4 w-4 text-muted-foreground" />
                      <p className="text-sm font-medium">{a.title}</p>
                    </div>
                    <p className="text-xs text-muted-foreground">Due {new Date(a.deadline).toLocaleDateString()}</p>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
