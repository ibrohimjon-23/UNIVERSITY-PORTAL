import type { Metadata } from "next";
import { Layers, Users } from "lucide-react";
import { requireRole } from "@/lib/auth";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { EmptyState } from "@/components/shared/empty-state";
import { getGroupById } from "@/features/groups/queries";
import { listGroupStudentsLite } from "@/features/students/queries";
import { initials } from "@/lib/utils";

export const metadata: Metadata = { title: "My Group" };

export default async function StudentGroupPage() {
  const student = await requireRole("student");

  if (!student.group_id) {
    return <EmptyState icon={Layers} title="No group assigned" description="Contact an administrator to be assigned to a group." />;
  }

  const [group, classmates] = await Promise.all([
    getGroupById(student.group_id),
    listGroupStudentsLite(student.group_id),
  ]);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight">{group?.group_name}</h1>
        <p className="text-sm text-muted-foreground">
          {group?.faculty} · Course {group?.course} · {group?.year}
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Group leader</CardTitle>
        </CardHeader>
        <CardContent>
          {group?.leader ? (
            <div className="flex items-center gap-3">
              <Avatar>
                <AvatarFallback>{initials(group.leader.first_name, group.leader.last_name)}</AvatarFallback>
              </Avatar>
              <div>
                <p className="text-sm font-medium">
                  {group.leader.first_name} {group.leader.last_name}
                </p>
                <p className="text-xs text-muted-foreground">@{group.leader.username}</p>
              </div>
            </div>
          ) : (
            <p className="text-sm text-muted-foreground">No leader assigned yet.</p>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Classmates</CardTitle>
          <CardDescription>{classmates.length} students in this group.</CardDescription>
        </CardHeader>
        <CardContent>
          {classmates.length === 0 ? (
            <EmptyState icon={Users} title="No classmates yet" />
          ) : (
            <div className="grid gap-3 sm:grid-cols-2">
              {classmates.map((c) => (
                <div key={c.id} className="flex items-center gap-3 rounded-md border p-3">
                  <Avatar>
                    <AvatarFallback>{initials(c.first_name, c.last_name)}</AvatarFallback>
                  </Avatar>
                  <div className="min-w-0">
                    <p className="truncate text-sm font-medium">
                      {c.first_name} {c.last_name}
                      {c.id === student.id ? <Badge variant="outline" className="ml-2">You</Badge> : null}
                    </p>
                    <p className="text-xs text-muted-foreground">{c.student_id}</p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
