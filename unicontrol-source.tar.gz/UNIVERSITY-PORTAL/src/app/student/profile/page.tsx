import type { Metadata } from "next";
import { requireRole } from "@/lib/auth";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { ProfileForm } from "@/features/profile/profile-form";
import { ChangePinDialog } from "@/features/profile/change-pin-dialog";

export const metadata: Metadata = { title: "My Profile" };

export default async function StudentProfilePage() {
  const student = await requireRole("student");

  return (
    <div className="max-w-2xl space-y-6">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight">My Profile</h1>
        <p className="text-sm text-muted-foreground">Manage your personal information and sign-in PIN.</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Personal information</CardTitle>
        </CardHeader>
        <CardContent>
          <ProfileForm profile={student} />
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Security</CardTitle>
          <CardDescription>Change the PIN you use to sign in.</CardDescription>
        </CardHeader>
        <CardContent>
          <ChangePinDialog />
        </CardContent>
      </Card>
    </div>
  );
}
