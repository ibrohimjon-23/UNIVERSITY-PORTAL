import { cookies } from "next/headers";
import { createServerClient, type CookieOptions } from "@supabase/ssr";

/**
 * Server-side Supabase client bound to the current request's cookies.
 * Use inside Server Components, Server Actions and Route Handlers.
 * Respects Row Level Security for the signed-in user (auth.uid()).
 *
 * Not parameterized with our Database type — see the comment in
 * `lib/supabase/client.ts` for why. Row shapes are asserted at each
 * call site via `@/types/database` instead.
 */
export async function createClient() {
  const cookieStore = await cookies();

  return createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        getAll() {
          return cookieStore.getAll();
        },
        setAll(cookiesToSet: { name: string; value: string; options: CookieOptions }[]) {
          try {
            cookiesToSet.forEach(({ name, value, options }) => {
              cookieStore.set(name, value, options);
            });
          } catch {
            // setAll is called from a Server Component in some cases; the
            // middleware is responsible for refreshing the session there.
          }
        },
      },
    },
  );
}
