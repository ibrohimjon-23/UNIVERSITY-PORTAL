"use client";

import { createBrowserClient } from "@supabase/ssr";

/**
 * Browser-side Supabase client for use inside Client Components
 * (e.g. reading the Geolocation API result and calling a Server Action).
 *
 * We intentionally don't parameterize this with our Database type: the
 * installed @supabase/ssr and @supabase/supabase-js versions disagree on
 * the exact shape of their internal `GenericSchema` constraint, which
 * makes a fully generic client resolve every table's row type to `never`
 * instead of raising a clear error. Row shapes are asserted explicitly
 * at each call site via the types in `@/types/database` instead, while
 * Postgres Row Level Security remains the actual security boundary.
 */
export function createClient() {
  return createBrowserClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!);
}
