"use client";

import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { Trash2, Users } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ConfirmDialog } from "@/components/shared/confirm-dialog";
import { AssignmentFormDialog } from "@/features/assignments/assignment-form-dialog";
import { SubmissionsDialog } from "@/features/assignments/submissions-dialog";
import { deleteAssignmentAction } from "@/features/assignments/actions";
import type { AssignmentWithRelations } from "@/features/assignments/queries";
import type { SubmissionWithStudent } from "@/features/assignments/queries";
import type { Group, Subject } from "@/types/database";

interface AssignmentRowActionsProps {
  assignment: AssignmentWithRelations;
  submissions: SubmissionWithStudent[];
  groups: Group[];
  subjects: Subject[];
  lockedGroupId?: string;
}

export function AssignmentRowActions({ assignment, submissions, groups, subjects, lockedGroupId }: AssignmentRowActionsProps) {
  const router = useRouter();

  return (
    <div className="flex items-center justify-end gap-1">
      <SubmissionsDialog
        submissions={submissions}
        trigger={
          <Button variant="ghost" size="icon" aria-label="View submissions">
            <Users className="h-4 w-4" />
          </Button>
        }
      />
      <AssignmentFormDialog assignment={assignment} groups={groups} subjects={subjects} lockedGroupId={lockedGroupId} />
      <ConfirmDialog
        trigger={
          <Button variant="ghost" size="icon" aria-label="Delete assignment">
            <Trash2 className="h-4 w-4 text-destructive" />
          </Button>
        }
        title="Delete assignment?"
        description={`Delete "${assignment.title}" and all its submissions?`}
        onConfirm={async () => {
          const result = await deleteAssignmentAction(assignment.id);
          if (result.error) toast.error(result.error);
          else {
            toast.success("Assignment deleted");
            router.refresh();
          }
        }}
      />
    </div>
  );
}
