"use client";

import { useActionState, useEffect, useRef, useState } from "react";
import { useFormStatus } from "react-dom";
import { useRouter } from "next/navigation";
import { Loader2 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogTrigger,
} from "@/components/ui/dialog";
import { reviewSubmissionAction, type ActionResult } from "@/features/assignments/actions";
import type { AssignmentSubmission } from "@/types/database";

const initial: ActionResult = {};

function SubmitButton() {
  const { pending } = useFormStatus();
  return (
    <Button type="submit" disabled={pending}>
      {pending ? <Loader2 className="h-4 w-4 animate-spin" /> : null}
      Save review
    </Button>
  );
}

export function ReviewSubmissionDialog({ submission, trigger }: { submission: AssignmentSubmission; trigger: React.ReactNode }) {
  const [state, formAction] = useActionState(reviewSubmissionAction, initial);
  const [open, setOpen] = useState(false);
  const router = useRouter();
  const formRef = useRef<HTMLFormElement>(null);

  useEffect(() => {
    if (state.success) {
      toast.success("Review saved");
      setOpen(false);
      router.refresh();
    } else if (state.error) toast.error(state.error);
  }, [state, router]);

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>{trigger}</DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Review submission</DialogTitle>
        </DialogHeader>
        {submission.text_answer ? (
          <div className="rounded-md border bg-muted/30 p-3 text-sm">{submission.text_answer}</div>
        ) : null}
        <form ref={formRef} action={formAction} className="space-y-4">
          <input type="hidden" name="submission_id" value={submission.id} />
          <div className="space-y-2">
            <Label htmlFor="grade">Grade (0–100)</Label>
            <Input id="grade" name="grade" type="number" min={0} max={100} step="0.5" defaultValue={submission.grade ?? ""} />
          </div>
          <div className="space-y-2">
            <Label htmlFor="feedback">Feedback</Label>
            <Textarea id="feedback" name="feedback" defaultValue={submission.feedback ?? ""} rows={4} />
          </div>
          <DialogFooter>
            <SubmitButton />
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
