"use client";

import { useState } from "react";
import { toast } from "sonner";
import { Download, Eye } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { EmptyState } from "@/components/shared/empty-state";
import { ReviewSubmissionDialog } from "@/features/assignments/review-submission-dialog";
import { getSubmissionDownloadUrlAction } from "@/features/assignments/actions";
import type { SubmissionWithStudent } from "@/features/assignments/queries";
import { FileText } from "lucide-react";

const STATUS_VARIANT = {
  pending: "outline",
  submitted: "secondary",
  late: "warning",
  reviewed: "success",
} as const;

export function SubmissionsDialog({ submissions, trigger }: { submissions: SubmissionWithStudent[]; trigger: React.ReactNode }) {
  const [open, setOpen] = useState(false);

  const download = async (path: string) => {
    const result = await getSubmissionDownloadUrlAction(path);
    if (result.error || !result.url) {
      toast.error(result.error ?? "Could not download file.");
      return;
    }
    window.open(result.url, "_blank");
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>{trigger}</DialogTrigger>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>Submissions ({submissions.length})</DialogTitle>
        </DialogHeader>
        {submissions.length === 0 ? (
          <EmptyState icon={FileText} title="No submissions yet" />
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Student</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Grade</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {submissions.map((s) => (
                <TableRow key={s.id}>
                  <TableCell>
                    {s.student ? `${s.student.first_name} ${s.student.last_name}` : "Unknown"}
                    <div className="text-xs text-muted-foreground">{s.student?.student_id}</div>
                  </TableCell>
                  <TableCell>
                    <Badge variant={STATUS_VARIANT[s.status]} className="capitalize">
                      {s.status}
                    </Badge>
                  </TableCell>
                  <TableCell>{s.grade != null ? s.grade : "—"}</TableCell>
                  <TableCell className="flex justify-end gap-1">
                    {s.file_path ? (
                      <Button variant="ghost" size="icon" onClick={() => download(s.file_path!)} aria-label="Download file">
                        <Download className="h-4 w-4" />
                      </Button>
                    ) : null}
                    <ReviewSubmissionDialog
                      submission={s}
                      trigger={
                        <Button variant="ghost" size="icon" aria-label="Review submission">
                          <Eye className="h-4 w-4" />
                        </Button>
                      }
                    />
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </DialogContent>
    </Dialog>
  );
}
