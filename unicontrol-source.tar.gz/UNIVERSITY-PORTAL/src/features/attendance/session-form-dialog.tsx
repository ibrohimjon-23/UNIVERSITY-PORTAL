"use client";

import { useActionState, useEffect, useRef, useState } from "react";
import { useFormStatus } from "react-dom";
import { useRouter } from "next/navigation";
import { Loader2, Plus } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
  DialogTrigger,
} from "@/components/ui/dialog";
import { createAttendanceSessionAction, type CreateSessionResult } from "@/features/attendance/actions";
import type { Group, Subject, Teacher } from "@/types/database";

const initial: CreateSessionResult = {};

function SubmitButton() {
  const { pending } = useFormStatus();
  return (
    <Button type="submit" disabled={pending}>
      {pending ? <Loader2 className="h-4 w-4 animate-spin" /> : null}
      Start session
    </Button>
  );
}

interface SessionFormDialogProps {
  groups: Group[];
  subjects: Subject[];
  teachers: Teacher[];
  lockedGroupId?: string;
}

export function SessionFormDialog({ groups, subjects, teachers, lockedGroupId }: SessionFormDialogProps) {
  const [state, formAction] = useActionState(createAttendanceSessionAction, initial);
  const [open, setOpen] = useState(false);
  const [groupId, setGroupId] = useState(lockedGroupId ?? groups[0]?.id ?? "");
  const [subjectId, setSubjectId] = useState(subjects[0]?.id ?? "");
  const [teacherId, setTeacherId] = useState("");
  const router = useRouter();
  const formRef = useRef<HTMLFormElement>(null);

  useEffect(() => {
    if (state.success) {
      toast.success("Attendance session started");
      setOpen(false);
      formRef.current?.reset();
      router.push(`${lockedGroupId ? "/leader" : "/admin"}/attendance/${state.sessionId}`);
    } else if (state.error) {
      toast.error(state.error);
    }
  }, [state, lockedGroupId, router]);

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button>
          <Plus className="h-4 w-4" />
          Start attendance
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Start attendance session</DialogTitle>
          <DialogDescription>
            A live QR code and geofence check will be required for students to check in.
          </DialogDescription>
        </DialogHeader>
        <form ref={formRef} action={formAction} className="space-y-4">
          {!lockedGroupId ? (
            <div className="space-y-2">
              <Label>Group</Label>
              <input type="hidden" name="group_id" value={groupId} />
              <Select value={groupId} onValueChange={setGroupId}>
                <SelectTrigger>
                  <SelectValue placeholder="Select a group" />
                </SelectTrigger>
                <SelectContent>
                  {groups.map((g) => (
                    <SelectItem key={g.id} value={g.id}>
                      {g.group_name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          ) : (
            <input type="hidden" name="group_id" value={groupId} />
          )}
          <div className="space-y-2">
            <Label>Subject</Label>
            <input type="hidden" name="subject_id" value={subjectId} />
            <Select value={subjectId} onValueChange={setSubjectId}>
              <SelectTrigger>
                <SelectValue placeholder="Select a subject" />
              </SelectTrigger>
              <SelectContent>
                {subjects.map((s) => (
                  <SelectItem key={s.id} value={s.id}>
                    {s.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label>Teacher</Label>
            <input type="hidden" name="teacher_id" value={teacherId} />
            <Select value={teacherId || "none"} onValueChange={(v) => setTeacherId(v === "none" ? "" : v)}>
              <SelectTrigger>
                <SelectValue placeholder="No teacher" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="none">No teacher</SelectItem>
                {teachers.map((t) => (
                  <SelectItem key={t.id} value={t.id}>
                    {t.first_name} {t.last_name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label htmlFor="duration_minutes">Duration (minutes)</Label>
            <Input id="duration_minutes" name="duration_minutes" type="number" min={5} max={240} defaultValue={90} required />
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => setOpen(false)}>
              Cancel
            </Button>
            <SubmitButton />
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
