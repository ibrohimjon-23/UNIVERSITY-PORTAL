"use client";

import { useCallback, useState } from "react";
import { useRouter } from "next/navigation";
import { CheckCircle2, Loader2, MapPin, ScanLine, XCircle } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { QrScanner } from "@/components/shared/qr-scanner";
import {
  getCurrentPosition,
  haversineMeters,
  GeolocationDeniedError,
  GeolocationUnsupportedError,
  type GeoPosition,
} from "@/lib/geo";
import { decodeAttendanceQr } from "@/lib/qr";
import { submitAttendanceAction } from "@/features/attendance/actions";

type Step = "idle" | "locating" | "scanning" | "submitting" | "success" | "error";

interface StudentCheckinProps {
  activeSessionId: string | null;
  subjectName: string | null;
  universityLat: number;
  universityLng: number;
  radiusMeters: number;
}

export function StudentCheckin({ activeSessionId, subjectName, universityLat, universityLng, radiusMeters }: StudentCheckinProps) {
  const [step, setStep] = useState<Step>("idle");
  const [position, setPosition] = useState<GeoPosition | null>(null);
  const [resultMessage, setResultMessage] = useState<string | null>(null);
  const [resultStatus, setResultStatus] = useState<string | null>(null);
  const router = useRouter();

  const estimatedDistance = position ? Math.round(haversineMeters(position.latitude, position.longitude, universityLat, universityLng)) : null;

  const startCheckIn = useCallback(async () => {
    setStep("locating");
    setResultMessage(null);
    try {
      const pos = await getCurrentPosition();
      setPosition(pos);
      setStep("scanning");
    } catch (err) {
      if (err instanceof GeolocationDeniedError) {
        toast.error("Location permission was denied. Enable it in your browser settings to check attendance.");
      } else if (err instanceof GeolocationUnsupportedError) {
        toast.error("Your device does not support location services.");
      } else {
        toast.error("Could not determine your location. Try again.");
      }
      setStep("idle");
    }
  }, []);

  const handleScan = useCallback(
    async (raw: string) => {
      if (!position || step !== "scanning") return;
      const payload = decodeAttendanceQr(raw);
      if (!payload) {
        toast.error("That doesn't look like a valid attendance QR code.");
        return;
      }

      setStep("submitting");
      const result = await submitAttendanceAction({
        sessionId: payload.sessionId,
        qrToken: payload.token,
        latitude: position.latitude,
        longitude: position.longitude,
        accuracy: position.accuracy,
      });

      if (result.error) {
        setResultMessage(result.error);
        setResultStatus(null);
        setStep("error");
      } else {
        setResultMessage(result.message ?? "Attendance recorded.");
        setResultStatus(result.status ?? null);
        setStep("success");
        router.refresh();
      }
    },
    [position, step, router],
  );

  if (!activeSessionId) {
    return (
      <Card>
        <CardContent className="flex flex-col items-center gap-2 py-12 text-center">
          <MapPin className="h-8 w-8 text-muted-foreground" />
          <p className="font-medium">No active attendance session</p>
          <p className="text-sm text-muted-foreground">
            Your leader or teacher hasn&apos;t started attendance for this class yet.
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardContent className="flex flex-col items-center gap-4 py-8">
        {subjectName ? <p className="text-sm text-muted-foreground">Session: {subjectName}</p> : null}

        {step === "idle" ? (
          <>
            <MapPin className="h-10 w-10 text-primary" />
            <Button size="lg" onClick={startCheckIn}>
              Check Attendance
            </Button>
            <p className="max-w-sm text-center text-xs text-muted-foreground">
              You&apos;ll be asked for your location, then to scan the QR code shown by your teacher or leader.
            </p>
          </>
        ) : null}

        {step === "locating" ? (
          <>
            <Loader2 className="h-10 w-10 animate-spin text-primary" />
            <p className="text-sm text-muted-foreground">Getting your location…</p>
          </>
        ) : null}

        {step === "scanning" ? (
          <div className="w-full space-y-3">
            {estimatedDistance !== null ? (
              <p className="text-center text-xs text-muted-foreground">
                Estimated distance from campus: ~{estimatedDistance}m (radius: {radiusMeters}m)
              </p>
            ) : null}
            <QrScanner active onScan={handleScan} />
            <p className="flex items-center justify-center gap-1 text-center text-xs text-muted-foreground">
              <ScanLine className="h-3 w-3" /> Scan the code on the classroom screen
            </p>
          </div>
        ) : null}

        {step === "submitting" ? (
          <>
            <Loader2 className="h-10 w-10 animate-spin text-primary" />
            <p className="text-sm text-muted-foreground">Verifying and recording attendance…</p>
          </>
        ) : null}

        {step === "success" ? (
          <Alert variant="success" className="w-full">
            <CheckCircle2 className="h-4 w-4" />
            <AlertTitle className="capitalize">{resultStatus ?? "Recorded"}</AlertTitle>
            <AlertDescription>{resultMessage}</AlertDescription>
          </Alert>
        ) : null}

        {step === "error" ? (
          <>
            <Alert variant="destructive" className="w-full">
              <XCircle className="h-4 w-4" />
              <AlertTitle>Attendance not recorded</AlertTitle>
              <AlertDescription>{resultMessage}</AlertDescription>
            </Alert>
            <Button variant="outline" onClick={() => setStep("idle")}>
              Try again
            </Button>
          </>
        ) : null}
      </CardContent>
    </Card>
  );
}
