import "server-only";
import { createClient } from "@/lib/supabase/server";
import type { AttendanceRecord, AttendanceSession, Profile, Subject } from "@/types/database";

export interface SessionWithSubject extends AttendanceSession {
  subject: Subject | null;
  present_count: number;
  total_count: number;
}

export interface ListSessionsParams {
  groupId?: string;
  page?: number;
  pageSize?: number;
}

export async function listAttendanceSessions(params: ListSessionsParams) {
  const supabase = await createClient();
  const page = params.page ?? 1;
  const pageSize = params.pageSize ?? 10;
  const from = (page - 1) * pageSize;
  const to = from + pageSize - 1;

  let query = supabase.from("attendance_sessions").select("*", { count: "exact" });
  if (params.groupId) query = query.eq("group_id", params.groupId);

  const { data, count, error } = await query.order("created_at", { ascending: false }).range(from, to);
  if (error) throw error;

  const sessions = (data ?? []) as AttendanceSession[];
  const subjectIds = Array.from(new Set(sessions.map((s) => s.subject_id)));
  const { data: subjects } = subjectIds.length
    ? await supabase.from("subjects").select("*").in("id", subjectIds)
    : { data: [] as Subject[] };
  const subjectById = new Map((subjects ?? []).map((s) => [s.id, s]));

  const sessionIds = sessions.map((s) => s.id);
  const counts = new Map<string, { present: number; total: number }>();
  if (sessionIds.length > 0) {
    const { data: records } = await supabase
      .from("attendance_records")
      .select("attendance_session_id, status")
      .in("attendance_session_id", sessionIds);
    for (const r of records ?? []) {
      const entry = counts.get(r.attendance_session_id) ?? { present: 0, total: 0 };
      entry.total += 1;
      if (r.status === "present" || r.status === "late") entry.present += 1;
      counts.set(r.attendance_session_id, entry);
    }
  }

  const rows: SessionWithSubject[] = sessions.map((s) => ({
    ...s,
    subject: subjectById.get(s.subject_id) ?? null,
    present_count: counts.get(s.id)?.present ?? 0,
    total_count: counts.get(s.id)?.total ?? 0,
  }));

  return { rows, total: count ?? 0, page, pageSize };
}

export async function getActiveSessionForGroup(groupId: string): Promise<AttendanceSession | null> {
  const supabase = await createClient();
  const { data } = await supabase
    .from("attendance_sessions")
    .select("*")
    .eq("group_id", groupId)
    .eq("status", "active")
    .gt("end_time", new Date().toISOString())
    .order("created_at", { ascending: false })
    .limit(1)
    .maybeSingle();
  return data as AttendanceSession | null;
}

export interface RecordWithStudent extends AttendanceRecord {
  student: Pick<Profile, "id" | "first_name" | "last_name" | "student_id"> | null;
}

export async function getSessionDetail(sessionId: string): Promise<{
  session: AttendanceSession | null;
  records: RecordWithStudent[];
  groupStudents: Profile[];
}> {
  const supabase = await createClient();
  const { data: session } = await supabase.from("attendance_sessions").select("*").eq("id", sessionId).maybeSingle();
  if (!session) return { session: null, records: [], groupStudents: [] };

  const [{ data: records }, { data: groupStudents }] = await Promise.all([
    supabase.from("attendance_records").select("*").eq("attendance_session_id", sessionId),
    supabase.from("profiles").select("*").eq("group_id", session.group_id).eq("role", "student").eq("is_active", true),
  ]);

  const studentById = new Map((groupStudents ?? []).map((s) => [s.id, s]));
  const recordsWithStudent: RecordWithStudent[] = (records ?? []).map((r) => ({
    ...(r as AttendanceRecord),
    student: studentById.get(r.student_id) ?? null,
  }));

  return { session: session as AttendanceSession, records: recordsWithStudent, groupStudents: (groupStudents ?? []) as Profile[] };
}

export interface StudentAttendanceRow extends AttendanceRecord {
  subject: Subject | null;
  session: Pick<AttendanceSession, "id" | "session_date"> | null;
}

export async function listStudentAttendance(studentId: string, page = 1, pageSize = 15) {
  const supabase = await createClient();
  const from = (page - 1) * pageSize;
  const to = from + pageSize - 1;

  const { data, count, error } = await supabase
    .from("attendance_records")
    .select("*", { count: "exact" })
    .eq("student_id", studentId)
    .order("checked_at", { ascending: false })
    .range(from, to);
  if (error) throw error;

  const records = (data ?? []) as AttendanceRecord[];
  const subjectIds = Array.from(new Set(records.map((r) => r.subject_id)));
  const sessionIds = Array.from(new Set(records.map((r) => r.attendance_session_id)));

  const [{ data: subjects }, { data: sessions }] = await Promise.all([
    subjectIds.length ? supabase.from("subjects").select("*").in("id", subjectIds) : Promise.resolve({ data: [] as Subject[] }),
    sessionIds.length
      ? supabase.from("attendance_sessions").select("id, session_date").in("id", sessionIds)
      : Promise.resolve({ data: [] as Pick<AttendanceSession, "id" | "session_date">[] }),
  ]);

  const subjectById = new Map((subjects ?? []).map((s) => [s.id, s]));
  const sessionById = new Map((sessions ?? []).map((s) => [s.id, s]));

  const rows: StudentAttendanceRow[] = records.map((r) => ({
    ...r,
    subject: subjectById.get(r.subject_id) ?? null,
    session: sessionById.get(r.attendance_session_id) ?? null,
  }));

  return { rows, total: count ?? 0, page, pageSize };
}

export async function getStudentAttendanceSummary(studentId: string) {
  const supabase = await createClient();
  const { data } = await supabase.from("attendance_records").select("status").eq("student_id", studentId);
  const summary = { present: 0, late: 0, absent: 0, excused: 0, total: data?.length ?? 0 };
  for (const row of data ?? []) {
    if (row.status === "present") summary.present += 1;
    else if (row.status === "late") summary.late += 1;
    else if (row.status === "absent") summary.absent += 1;
    else if (row.status === "excused") summary.excused += 1;
  }
  return summary;
}
