"use server";

import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { requireRole } from "@/lib/auth";
import { logAudit } from "@/lib/audit";
import { groupSchema } from "@/validators/group";

export interface ActionResult {
  error?: string;
  success?: boolean;
}

export async function createGroupAction(_prev: ActionResult, formData: FormData): Promise<ActionResult> {
  const admin = await requireRole("admin");
  const parsed = groupSchema.safeParse({
    group_name: formData.get("group_name"),
    faculty: formData.get("faculty"),
    course: formData.get("course"),
    year: formData.get("year"),
    description: formData.get("description"),
  });

  if (!parsed.success) {
    return { error: parsed.error.issues[0]?.message ?? "Invalid input." };
  }

  const supabase = await createClient();
  const { data, error } = await supabase
    .from("groups")
    .insert({
      group_name: parsed.data.group_name,
      faculty: parsed.data.faculty,
      course: parsed.data.course,
      year: parsed.data.year,
      description: parsed.data.description || null,
    })
    .select()
    .single();

  if (error) {
    return { error: error.code === "23505" ? "A group with this name already exists." : "Could not create group." };
  }

  await logAudit({ actorId: admin.id, action: "group.create", entityType: "group", entityId: data.id, newData: data });
  revalidatePath("/admin/groups");
  return { success: true };
}

export async function updateGroupAction(_prev: ActionResult, formData: FormData): Promise<ActionResult> {
  const admin = await requireRole("admin");
  const id = String(formData.get("id") ?? "");
  const parsed = groupSchema.safeParse({
    group_name: formData.get("group_name"),
    faculty: formData.get("faculty"),
    course: formData.get("course"),
    year: formData.get("year"),
    description: formData.get("description"),
  });

  if (!id || !parsed.success) {
    return { error: parsed.success ? "Missing group id." : parsed.error.issues[0]?.message };
  }

  const supabase = await createClient();
  const { data: before } = await supabase.from("groups").select("*").eq("id", id).maybeSingle();

  const { data, error } = await supabase
    .from("groups")
    .update({
      group_name: parsed.data.group_name,
      faculty: parsed.data.faculty,
      course: parsed.data.course,
      year: parsed.data.year,
      description: parsed.data.description || null,
    })
    .eq("id", id)
    .select()
    .single();

  if (error) {
    return { error: error.code === "23505" ? "A group with this name already exists." : "Could not update group." };
  }

  await logAudit({
    actorId: admin.id,
    action: "group.update",
    entityType: "group",
    entityId: id,
    oldData: before,
    newData: data,
  });
  revalidatePath("/admin/groups");
  return { success: true };
}

export async function deleteGroupAction(id: string): Promise<ActionResult> {
  const admin = await requireRole("admin");
  const supabase = await createClient();

  const { data: before } = await supabase.from("groups").select("*").eq("id", id).maybeSingle();
  const { error } = await supabase.from("groups").delete().eq("id", id);

  if (error) {
    return {
      error:
        error.code === "23503"
          ? "Cannot delete this group while it still has students, schedules or records. Reassign or remove them first."
          : "Could not delete group.",
    };
  }

  await logAudit({ actorId: admin.id, action: "group.delete", entityType: "group", entityId: id, oldData: before });
  revalidatePath("/admin/groups");
  return { success: true };
}

export async function assignLeaderAction(groupId: string, leaderId: string): Promise<ActionResult> {
  const admin = await requireRole("admin");
  const supabase = await createClient();

  const { error } = await supabase.rpc("fn_assign_leader", { p_group_id: groupId, p_leader_id: leaderId });
  if (error) return { error: error.message };

  await logAudit({
    actorId: admin.id,
    action: "group.assign_leader",
    entityType: "group",
    entityId: groupId,
    newData: { leader_id: leaderId },
  });
  revalidatePath("/admin/groups");
  revalidatePath("/admin/leaders");
  return { success: true };
}

export async function unassignLeaderAction(groupId: string): Promise<ActionResult> {
  const admin = await requireRole("admin");
  const supabase = await createClient();

  const { error } = await supabase.rpc("fn_unassign_leader", { p_group_id: groupId });
  if (error) return { error: error.message };

  await logAudit({ actorId: admin.id, action: "group.unassign_leader", entityType: "group", entityId: groupId });
  revalidatePath("/admin/groups");
  revalidatePath("/admin/leaders");
  return { success: true };
}
