import "server-only";
import { createClient } from "@/lib/supabase/server";
import type { Group, Profile } from "@/types/database";

export interface GroupWithRelations extends Group {
  leader: Pick<Profile, "id" | "first_name" | "last_name" | "username"> | null;
  student_count: number;
}

export interface ListGroupsParams {
  query?: string;
  faculty?: string;
  course?: number;
  page?: number;
  pageSize?: number;
}

export async function listGroups(params: ListGroupsParams) {
  const supabase = await createClient();
  const page = params.page ?? 1;
  const pageSize = params.pageSize ?? 10;
  const from = (page - 1) * pageSize;
  const to = from + pageSize - 1;

  let query = supabase
    .from("groups")
    .select("*, leader:profiles!fk_groups_leader(id, first_name, last_name, username)", { count: "exact" });

  if (params.query) {
    query = query.or(`group_name.ilike.%${params.query}%,faculty.ilike.%${params.query}%`);
  }
  if (params.faculty) {
    query = query.eq("faculty", params.faculty);
  }
  if (params.course) {
    query = query.eq("course", params.course);
  }

  const { data, count, error } = await query.order("created_at", { ascending: false }).range(from, to);
  if (error) throw error;

  const groupIds = (data ?? []).map((g) => g.id);
  const counts = new Map<string, number>();

  if (groupIds.length > 0) {
    const { data: memberRows } = await supabase.from("profiles").select("group_id").in("group_id", groupIds).eq("role", "student");
    for (const row of memberRows ?? []) {
      if (row.group_id) counts.set(row.group_id, (counts.get(row.group_id) ?? 0) + 1);
    }
  }

  const rows: GroupWithRelations[] = (data ?? []).map((g) => ({
    ...(g as unknown as Group),
    leader: (g as unknown as { leader: GroupWithRelations["leader"] }).leader,
    student_count: counts.get(g.id) ?? 0,
  }));

  return { rows, total: count ?? 0, page, pageSize };
}

export async function listAllGroups(): Promise<Group[]> {
  const supabase = await createClient();
  const { data, error } = await supabase.from("groups").select("*").order("group_name");
  if (error) throw error;
  return data as Group[];
}

export async function getDistinctFaculties(): Promise<string[]> {
  const supabase = await createClient();
  const { data } = await supabase.from("groups").select("faculty");
  return Array.from(new Set((data ?? []).map((row) => row.faculty))).sort();
}

export async function getGroupById(id: string): Promise<GroupWithRelations | null> {
  const supabase = await createClient();
  const { data, error } = await supabase
    .from("groups")
    .select("*, leader:profiles!fk_groups_leader(id, first_name, last_name, username)")
    .eq("id", id)
    .maybeSingle();
  if (error || !data) return null;

  const { count } = await supabase
    .from("profiles")
    .select("id", { count: "exact", head: true })
    .eq("group_id", id)
    .eq("role", "student");

  return {
    ...(data as unknown as Group),
    leader: (data as unknown as { leader: GroupWithRelations["leader"] }).leader,
    student_count: count ?? 0,
  };
}
