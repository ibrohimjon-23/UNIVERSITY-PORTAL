"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { Loader2, UserCog } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { assignLeaderAction, unassignLeaderAction } from "@/features/groups/actions";
import type { Profile } from "@/types/database";

interface AssignLeaderDialogProps {
  groupId: string;
  currentLeaderId?: string | null;
  availableLeaders: Profile[];
}

export function AssignLeaderDialog({ groupId, currentLeaderId, availableLeaders }: AssignLeaderDialogProps) {
  const [open, setOpen] = useState(false);
  const [leaderId, setLeaderId] = useState(currentLeaderId ?? "");
  const [pending, startTransition] = useTransition();
  const router = useRouter();

  const submit = () => {
    startTransition(async () => {
      const result = leaderId ? await assignLeaderAction(groupId, leaderId) : await unassignLeaderAction(groupId);
      if (result.error) {
        toast.error(result.error);
      } else {
        toast.success("Leader updated");
        setOpen(false);
        router.refresh();
      }
    });
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="ghost" size="icon" aria-label="Assign leader">
          <UserCog className="h-4 w-4" />
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Assign leader</DialogTitle>
          <DialogDescription>Choose which leader manages this group, or remove the current leader.</DialogDescription>
        </DialogHeader>
        <Select value={leaderId || "none"} onValueChange={(v) => setLeaderId(v === "none" ? "" : v)}>
          <SelectTrigger>
            <SelectValue placeholder="No leader" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="none">No leader</SelectItem>
            {availableLeaders.map((leader) => (
              <SelectItem key={leader.id} value={leader.id}>
                {leader.first_name} {leader.last_name} (@{leader.username})
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <DialogFooter>
          <Button type="button" variant="outline" onClick={() => setOpen(false)}>
            Cancel
          </Button>
          <Button onClick={submit} disabled={pending}>
            {pending ? <Loader2 className="h-4 w-4 animate-spin" /> : null}
            Save
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
