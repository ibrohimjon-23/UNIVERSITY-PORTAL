"use client";

import { useActionState, useEffect, useRef, useState } from "react";
import { useFormStatus } from "react-dom";
import { useRouter } from "next/navigation";
import { Loader2, Pencil, Plus } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
  DialogTrigger,
} from "@/components/ui/dialog";
import { createLeaderAction, updateLeaderAction, type ActionResult } from "@/features/leaders/actions";
import type { Group, Profile } from "@/types/database";

const initial: ActionResult = {};

function SubmitButton({ label }: { label: string }) {
  const { pending } = useFormStatus();
  return (
    <Button type="submit" disabled={pending}>
      {pending ? <Loader2 className="h-4 w-4 animate-spin" /> : null}
      {label}
    </Button>
  );
}

interface LeaderFormDialogProps {
  leader?: Profile;
  groups: Group[];
}

export function LeaderFormDialog({ leader, groups }: LeaderFormDialogProps) {
  const action = leader ? updateLeaderAction : createLeaderAction;
  const [state, formAction] = useActionState(action, initial);
  const [open, setOpen] = useState(false);
  const [groupId, setGroupId] = useState(groups[0]?.id ?? "");
  const router = useRouter();
  const formRef = useRef<HTMLFormElement>(null);

  useEffect(() => {
    if (state.success) {
      toast.success(leader ? "Leader updated" : "Leader created");
      setOpen(false);
      formRef.current?.reset();
      router.refresh();
    } else if (state.error) {
      toast.error(state.error);
    }
  }, [state, leader, router]);

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        {leader ? (
          <Button variant="ghost" size="icon" aria-label="Edit leader">
            <Pencil className="h-4 w-4" />
          </Button>
        ) : (
          <Button>
            <Plus className="h-4 w-4" />
            New leader
          </Button>
        )}
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>{leader ? "Edit leader" : "Create leader"}</DialogTitle>
          <DialogDescription>
            {leader
              ? "Update this leader's details."
              : "Leaders receive a username and PIN to sign in and manage their group."}
          </DialogDescription>
        </DialogHeader>
        <form ref={formRef} action={formAction} className="space-y-4">
          {leader ? <input type="hidden" name="id" value={leader.id} /> : null}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="first_name">First name</Label>
              <Input id="first_name" name="first_name" defaultValue={leader?.first_name} required />
            </div>
            <div className="space-y-2">
              <Label htmlFor="last_name">Last name</Label>
              <Input id="last_name" name="last_name" defaultValue={leader?.last_name} required />
            </div>
          </div>
          {!leader ? (
            <>
              <div className="space-y-2">
                <Label htmlFor="username">Username</Label>
                <Input id="username" name="username" required placeholder="jane.doe" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="pin">PIN</Label>
                <Input id="pin" name="pin" type="password" inputMode="numeric" required placeholder="At least 4 digits" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="group_id">Assigned group</Label>
                <input type="hidden" name="group_id" value={groupId} />
                <Select value={groupId} onValueChange={setGroupId}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select a group" />
                  </SelectTrigger>
                  <SelectContent>
                    {groups.map((g) => (
                      <SelectItem key={g.id} value={g.id}>
                        {g.group_name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </>
          ) : null}
          <div className="space-y-2">
            <Label htmlFor="phone">Phone</Label>
            <Input id="phone" name="phone" defaultValue={leader?.phone ?? ""} placeholder="+998901234567" />
          </div>
          {leader ? (
            <div className="space-y-2">
              <Label htmlFor="is_active">Status</Label>
              <input type="hidden" name="is_active" value={String(leader.is_active)} />
              <Select
                defaultValue={String(leader.is_active)}
                onValueChange={(v) => {
                  const el = formRef.current?.elements.namedItem("is_active") as HTMLInputElement | null;
                  if (el) el.value = v;
                }}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="true">Active</SelectItem>
                  <SelectItem value="false">Inactive</SelectItem>
                </SelectContent>
              </Select>
            </div>
          ) : null}
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => setOpen(false)}>
              Cancel
            </Button>
            <SubmitButton label={leader ? "Save changes" : "Create leader"} />
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
