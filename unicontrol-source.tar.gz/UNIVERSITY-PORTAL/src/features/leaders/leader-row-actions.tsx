"use client";

import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ConfirmDialog } from "@/components/shared/confirm-dialog";
import { ResetPinDialog } from "@/components/shared/reset-pin-dialog";
import { LeaderFormDialog } from "@/features/leaders/leader-form-dialog";
import { deleteLeaderAction, resetLeaderPinAction } from "@/features/leaders/actions";
import type { Group, Profile } from "@/types/database";

export function LeaderRowActions({ leader, groups }: { leader: Profile; groups: Group[] }) {
  const router = useRouter();

  return (
    <div className="flex items-center justify-end gap-1">
      <ResetPinDialog userId={leader.id} action={resetLeaderPinAction} />
      <LeaderFormDialog leader={leader} groups={groups} />
      <ConfirmDialog
        trigger={
          <Button variant="ghost" size="icon" aria-label="Delete leader">
            <Trash2 className="h-4 w-4 text-destructive" />
          </Button>
        }
        title="Delete leader?"
        description={`This permanently deletes ${leader.first_name} ${leader.last_name}'s account and removes them from any group they lead.`}
        confirmLabel="Delete"
        onConfirm={async () => {
          const result = await deleteLeaderAction(leader.id);
          if (result.error) {
            toast.error(result.error);
          } else {
            toast.success("Leader deleted");
            router.refresh();
          }
        }}
      />
    </div>
  );
}
