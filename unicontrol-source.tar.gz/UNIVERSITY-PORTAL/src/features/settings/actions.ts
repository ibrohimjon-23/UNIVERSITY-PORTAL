"use server";

import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { requireRole } from "@/lib/auth";
import { logAudit } from "@/lib/audit";
import { settingsSchema } from "@/validators/settings";

export interface ActionResult {
  error?: string;
  success?: boolean;
}

export async function updateSettingsAction(_prev: ActionResult, formData: FormData): Promise<ActionResult> {
  const admin = await requireRole("admin");
  const parsed = settingsSchema.safeParse({
    university_name: formData.get("university_name"),
    latitude: formData.get("latitude"),
    longitude: formData.get("longitude"),
    attendance_radius_m: formData.get("attendance_radius_m"),
    timezone: formData.get("timezone"),
    qr_expiry_seconds: formData.get("qr_expiry_seconds"),
    late_after_minutes: formData.get("late_after_minutes"),
  });

  if (!parsed.success) return { error: parsed.error.issues[0]?.message };

  const supabase = await createClient();
  const { data: before } = await supabase.from("university_settings").select("*").eq("id", 1).maybeSingle();
  const { error } = await supabase.from("university_settings").update(parsed.data).eq("id", 1);
  if (error) return { error: "Could not save settings." };

  await logAudit({
    actorId: admin.id,
    action: "settings.update",
    entityType: "university_settings",
    entityId: "1",
    oldData: before,
    newData: parsed.data,
  });

  revalidatePath("/admin/settings");
  return { success: true };
}
