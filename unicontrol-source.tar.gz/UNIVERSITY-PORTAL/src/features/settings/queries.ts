import "server-only";
import { createClient } from "@/lib/supabase/server";
import type { UniversitySettings } from "@/types/database";

export async function getUniversitySettings(): Promise<UniversitySettings> {
  const supabase = await createClient();
  const { data, error } = await supabase.from("university_settings").select("*").eq("id", 1).single();
  if (error) throw error;
  return data as UniversitySettings;
}
