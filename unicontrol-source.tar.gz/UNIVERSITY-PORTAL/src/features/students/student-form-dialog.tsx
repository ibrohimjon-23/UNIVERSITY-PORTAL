"use client";

import { useActionState, useEffect, useRef, useState } from "react";
import { useFormStatus } from "react-dom";
import { useRouter } from "next/navigation";
import { Loader2, Pencil, Plus } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
  DialogTrigger,
} from "@/components/ui/dialog";
import { createStudentAction, updateStudentAction, type ActionResult } from "@/features/students/actions";
import type { Group, Profile } from "@/types/database";

const initial: ActionResult = {};

function SubmitButton({ label }: { label: string }) {
  const { pending } = useFormStatus();
  return (
    <Button type="submit" disabled={pending}>
      {pending ? <Loader2 className="h-4 w-4 animate-spin" /> : null}
      {label}
    </Button>
  );
}

interface StudentFormDialogProps {
  student?: Profile;
  groups: Group[];
  /** If set, the group cannot be changed (used on the leader's own-group page). */
  lockedGroupId?: string;
}

export function StudentFormDialog({ student, groups, lockedGroupId }: StudentFormDialogProps) {
  const action = student ? updateStudentAction : createStudentAction;
  const [state, formAction] = useActionState(action, initial);
  const [open, setOpen] = useState(false);
  const [groupId, setGroupId] = useState(lockedGroupId ?? student?.group_id ?? groups[0]?.id ?? "");
  const router = useRouter();
  const formRef = useRef<HTMLFormElement>(null);

  useEffect(() => {
    if (state.success) {
      toast.success(student ? "Student updated" : "Student created");
      setOpen(false);
      formRef.current?.reset();
      router.refresh();
    } else if (state.error) {
      toast.error(state.error);
    }
  }, [state, student, router]);

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        {student ? (
          <Button variant="ghost" size="icon" aria-label="Edit student">
            <Pencil className="h-4 w-4" />
          </Button>
        ) : (
          <Button>
            <Plus className="h-4 w-4" />
            Add student
          </Button>
        )}
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>{student ? "Edit student" : "Add student"}</DialogTitle>
          <DialogDescription>
            {student ? "Update this student's details." : "Students receive a username and PIN to sign in."}
          </DialogDescription>
        </DialogHeader>
        <form ref={formRef} action={formAction} className="space-y-4">
          {student ? <input type="hidden" name="id" value={student.id} /> : null}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="first_name">First name</Label>
              <Input id="first_name" name="first_name" defaultValue={student?.first_name} required />
            </div>
            <div className="space-y-2">
              <Label htmlFor="last_name">Last name</Label>
              <Input id="last_name" name="last_name" defaultValue={student?.last_name} required />
            </div>
          </div>
          {!student ? (
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="username">Username</Label>
                <Input id="username" name="username" required placeholder="john.smith" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="pin">PIN</Label>
                <Input id="pin" name="pin" type="password" inputMode="numeric" required placeholder="At least 4 digits" />
              </div>
            </div>
          ) : null}
          <div className="space-y-2">
            <Label htmlFor="student_id">Student ID</Label>
            <Input id="student_id" name="student_id" defaultValue={student?.student_id ?? ""} required placeholder="S00123" />
          </div>
          <div className="space-y-2">
            <Label htmlFor="group_id">Group</Label>
            <input type="hidden" name="group_id" value={groupId} />
            {lockedGroupId ? (
              <Input value={groups.find((g) => g.id === lockedGroupId)?.group_name ?? ""} disabled />
            ) : (
              <Select value={groupId} onValueChange={setGroupId}>
                <SelectTrigger>
                  <SelectValue placeholder="Select a group" />
                </SelectTrigger>
                <SelectContent>
                  {groups.map((g) => (
                    <SelectItem key={g.id} value={g.id}>
                      {g.group_name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            )}
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="phone">Phone</Label>
              <Input id="phone" name="phone" defaultValue={student?.phone ?? ""} placeholder="+998901234567" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input id="email" name="email" type="email" defaultValue={student?.email ?? ""} />
            </div>
          </div>
          {student ? (
            <div className="space-y-2">
              <Label htmlFor="is_active">Status</Label>
              <input type="hidden" name="is_active" value={String(student.is_active)} />
              <Select
                defaultValue={String(student.is_active)}
                onValueChange={(v) => {
                  const el = formRef.current?.elements.namedItem("is_active") as HTMLInputElement | null;
                  if (el) el.value = v;
                }}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="true">Active</SelectItem>
                  <SelectItem value="false">Inactive</SelectItem>
                </SelectContent>
              </Select>
            </div>
          ) : null}
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => setOpen(false)}>
              Cancel
            </Button>
            <SubmitButton label={student ? "Save changes" : "Add student"} />
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
