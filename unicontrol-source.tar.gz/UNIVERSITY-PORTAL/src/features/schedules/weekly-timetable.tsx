import { CalendarDays, MapPin } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { EmptyState } from "@/components/shared/empty-state";
import { dayName, formatTime } from "@/lib/utils";
import type { ScheduleWithRelations } from "@/features/schedules/queries";

const WEEKDAY_ORDER = [1, 2, 3, 4, 5, 6, 0];

export function WeeklyTimetable({
  schedules,
  actions,
}: {
  schedules: ScheduleWithRelations[];
  actions?: (schedule: ScheduleWithRelations) => React.ReactNode;
}) {
  if (schedules.length === 0) {
    return <EmptyState icon={CalendarDays} title="No classes scheduled" description="Nothing has been added to this timetable yet." />;
  }

  const byDay = new Map<number, ScheduleWithRelations[]>();
  for (const s of schedules) {
    byDay.set(s.day_of_week, [...(byDay.get(s.day_of_week) ?? []), s]);
  }

  return (
    <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
      {WEEKDAY_ORDER.filter((d) => byDay.has(d)).map((day) => (
        <div key={day} className="rounded-lg border">
          <div className="border-b bg-muted/40 px-4 py-2 text-sm font-semibold">{dayName(day)}</div>
          <div className="divide-y">
            {byDay
              .get(day)!
              .sort((a, b) => a.start_time.localeCompare(b.start_time))
              .map((s) => (
                <div key={s.id} className="flex items-start justify-between gap-2 px-4 py-3">
                  <div className="space-y-1">
                    <p className="text-sm font-medium">{s.subject?.name ?? "Unknown subject"}</p>
                    <p className="text-xs text-muted-foreground">
                      {formatTime(s.start_time)} – {formatTime(s.end_time)}
                    </p>
                    <div className="flex items-center gap-2 text-xs text-muted-foreground">
                      <MapPin className="h-3 w-3" /> {s.room}
                      {s.teacher ? <Badge variant="outline">{s.teacher.first_name} {s.teacher.last_name}</Badge> : null}
                    </div>
                  </div>
                  {actions ? <div>{actions(s)}</div> : null}
                </div>
              ))}
          </div>
        </div>
      ))}
    </div>
  );
}
