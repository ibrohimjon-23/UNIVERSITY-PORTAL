import "server-only";
import { createClient } from "@/lib/supabase/server";
import type { Schedule, Subject, Teacher } from "@/types/database";

export interface ScheduleWithRelations extends Schedule {
  subject: Subject | null;
  teacher: Teacher | null;
}

export async function listSchedulesForGroup(groupId: string): Promise<ScheduleWithRelations[]> {
  const supabase = await createClient();
  const { data, error } = await supabase
    .from("schedules")
    .select("*")
    .eq("group_id", groupId)
    .order("day_of_week")
    .order("start_time");
  if (error) throw error;

  return attachRelations((data ?? []) as Schedule[]);
}

export async function listAllSchedules(): Promise<ScheduleWithRelations[]> {
  const supabase = await createClient();
  const { data, error } = await supabase.from("schedules").select("*").order("day_of_week").order("start_time");
  if (error) throw error;
  return attachRelations((data ?? []) as Schedule[]);
}

async function attachRelations(schedules: Schedule[]): Promise<ScheduleWithRelations[]> {
  if (schedules.length === 0) return [];
  const supabase = await createClient();
  const subjectIds = Array.from(new Set(schedules.map((s) => s.subject_id)));
  const teacherIds = Array.from(new Set(schedules.map((s) => s.teacher_id).filter(Boolean))) as string[];

  const [{ data: subjects }, { data: teachers }] = await Promise.all([
    supabase.from("subjects").select("*").in("id", subjectIds),
    teacherIds.length > 0
      ? supabase.from("teachers").select("*").in("id", teacherIds)
      : Promise.resolve({ data: [] as Teacher[] }),
  ]);

  const subjectById = new Map((subjects ?? []).map((s) => [s.id, s]));
  const teacherById = new Map((teachers ?? []).map((t) => [t.id, t]));

  return schedules.map((s) => ({
    ...s,
    subject: subjectById.get(s.subject_id) ?? null,
    teacher: s.teacher_id ? teacherById.get(s.teacher_id) ?? null : null,
  }));
}

export async function hasScheduleConflict(
  groupId: string,
  dayOfWeek: number,
  startTime: string,
  endTime: string,
  excludeId?: string,
): Promise<boolean> {
  const supabase = await createClient();
  let query = supabase
    .from("schedules")
    .select("id, start_time, end_time")
    .eq("group_id", groupId)
    .eq("day_of_week", dayOfWeek);
  if (excludeId) query = query.neq("id", excludeId);

  const { data } = await query;
  return (data ?? []).some((s) => startTime < s.end_time && endTime > s.start_time);
}
