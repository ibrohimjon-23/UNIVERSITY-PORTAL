"use server";

import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { requireRole } from "@/lib/auth";
import { logAudit } from "@/lib/audit";
import { scheduleSchema } from "@/validators/schedule";
import { hasScheduleConflict } from "@/features/schedules/queries";

export interface ActionResult {
  error?: string;
  success?: boolean;
}

export async function createScheduleAction(_prev: ActionResult, formData: FormData): Promise<ActionResult> {
  const admin = await requireRole("admin");
  const parsed = scheduleSchema.safeParse({
    group_id: formData.get("group_id"),
    subject_id: formData.get("subject_id"),
    teacher_id: formData.get("teacher_id"),
    room: formData.get("room"),
    day_of_week: formData.get("day_of_week"),
    start_time: formData.get("start_time"),
    end_time: formData.get("end_time"),
  });

  if (!parsed.success) return { error: parsed.error.issues[0]?.message };

  const conflict = await hasScheduleConflict(
    parsed.data.group_id,
    parsed.data.day_of_week,
    parsed.data.start_time,
    parsed.data.end_time,
  );
  if (conflict) return { error: "This group already has a class scheduled in that time slot." };

  const supabase = await createClient();
  const { data, error } = await supabase
    .from("schedules")
    .insert({
      group_id: parsed.data.group_id,
      subject_id: parsed.data.subject_id,
      teacher_id: parsed.data.teacher_id || null,
      room: parsed.data.room,
      day_of_week: parsed.data.day_of_week,
      start_time: parsed.data.start_time,
      end_time: parsed.data.end_time,
    })
    .select()
    .single();

  if (error) return { error: "Could not create schedule entry." };

  await logAudit({ actorId: admin.id, action: "schedule.create", entityType: "schedule", entityId: data.id, newData: data });
  revalidatePath("/admin/schedule");
  revalidatePath("/leader/schedule");
  revalidatePath("/student/schedule");
  return { success: true };
}

export async function updateScheduleAction(_prev: ActionResult, formData: FormData): Promise<ActionResult> {
  const admin = await requireRole("admin");
  const id = String(formData.get("id") ?? "");
  const parsed = scheduleSchema.safeParse({
    group_id: formData.get("group_id"),
    subject_id: formData.get("subject_id"),
    teacher_id: formData.get("teacher_id"),
    room: formData.get("room"),
    day_of_week: formData.get("day_of_week"),
    start_time: formData.get("start_time"),
    end_time: formData.get("end_time"),
  });

  if (!id || !parsed.success) return { error: parsed.success ? "Missing schedule id." : parsed.error.issues[0]?.message };

  const conflict = await hasScheduleConflict(
    parsed.data.group_id,
    parsed.data.day_of_week,
    parsed.data.start_time,
    parsed.data.end_time,
    id,
  );
  if (conflict) return { error: "This group already has a class scheduled in that time slot." };

  const supabase = await createClient();
  const { data: before } = await supabase.from("schedules").select("*").eq("id", id).maybeSingle();
  const { data, error } = await supabase
    .from("schedules")
    .update({
      group_id: parsed.data.group_id,
      subject_id: parsed.data.subject_id,
      teacher_id: parsed.data.teacher_id || null,
      room: parsed.data.room,
      day_of_week: parsed.data.day_of_week,
      start_time: parsed.data.start_time,
      end_time: parsed.data.end_time,
    })
    .eq("id", id)
    .select()
    .single();

  if (error) return { error: "Could not update schedule entry." };

  await logAudit({
    actorId: admin.id,
    action: "schedule.update",
    entityType: "schedule",
    entityId: id,
    oldData: before,
    newData: data,
  });
  revalidatePath("/admin/schedule");
  revalidatePath("/leader/schedule");
  revalidatePath("/student/schedule");
  return { success: true };
}

export async function deleteScheduleAction(id: string): Promise<ActionResult> {
  const admin = await requireRole("admin");
  const supabase = await createClient();
  const { data: before } = await supabase.from("schedules").select("*").eq("id", id).maybeSingle();
  const { error } = await supabase.from("schedules").delete().eq("id", id);
  if (error) return { error: "Could not delete schedule entry." };

  await logAudit({ actorId: admin.id, action: "schedule.delete", entityType: "schedule", entityId: id, oldData: before });
  revalidatePath("/admin/schedule");
  revalidatePath("/leader/schedule");
  revalidatePath("/student/schedule");
  return { success: true };
}
