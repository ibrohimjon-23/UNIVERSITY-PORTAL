"use server";

import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { usernameToAuthEmail, dashboardPathForRole } from "@/lib/auth";
import { loginSchema } from "@/validators/auth";
import { logAudit } from "@/lib/audit";
import type { Profile } from "@/types/database";

export interface LoginResult {
  error?: string;
}

export async function loginAction(_prev: LoginResult, formData: FormData): Promise<LoginResult> {
  const parsed = loginSchema.safeParse({
    username: formData.get("username"),
    pin: formData.get("pin"),
  });

  if (!parsed.success) {
    return { error: parsed.error.issues[0]?.message ?? "Invalid input." };
  }

  const supabase = await createClient();
  const email = usernameToAuthEmail(parsed.data.username);

  const { data, error } = await supabase.auth.signInWithPassword({
    email,
    password: parsed.data.pin,
  });

  if (error || !data.user) {
    return { error: "Invalid username or PIN." };
  }

  const { data: profile } = await supabase
    .from("profiles")
    .select("*")
    .eq("id", data.user.id)
    .maybeSingle<Profile>();

  if (!profile) {
    await supabase.auth.signOut();
    return { error: "Your account is not fully set up. Contact an administrator." };
  }

  if (!profile.is_active) {
    await supabase.auth.signOut();
    return { error: "Your account has been deactivated. Contact an administrator." };
  }

  await logAudit({
    actorId: profile.id,
    action: "login",
    entityType: "auth",
    entityId: profile.id,
  });

  redirect(dashboardPathForRole(profile.role));
}

export async function logoutAction(): Promise<void> {
  const supabase = await createClient();
  const { data } = await supabase.auth.getUser();

  if (data.user) {
    await logAudit({ actorId: data.user.id, action: "logout", entityType: "auth", entityId: data.user.id });
  }

  await supabase.auth.signOut();
  redirect("/login");
}
