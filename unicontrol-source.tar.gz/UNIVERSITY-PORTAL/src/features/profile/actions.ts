"use server";

import { revalidatePath } from "next/cache";
import { z } from "zod";
import { createClient } from "@/lib/supabase/server";
import { requireProfile } from "@/lib/auth";
import { logAudit } from "@/lib/audit";

export interface ActionResult {
  error?: string;
  success?: boolean;
}

const updateProfileSchema = z.object({
  phone: z
    .string()
    .trim()
    .regex(/^[0-9+\-\s()]{7,20}$/, "Enter a valid phone number")
    .optional()
    .or(z.literal("")),
  email: z.string().trim().email("Enter a valid email").optional().or(z.literal("")),
  avatar_url: z.string().trim().url().optional().or(z.literal("")),
});

export async function updateOwnProfileAction(_prev: ActionResult, formData: FormData): Promise<ActionResult> {
  const profile = await requireProfile();
  const parsed = updateProfileSchema.safeParse({
    phone: formData.get("phone"),
    email: formData.get("email"),
    avatar_url: formData.get("avatar_url"),
  });
  if (!parsed.success) return { error: parsed.error.issues[0]?.message };

  const supabase = await createClient();
  const { error } = await supabase
    .from("profiles")
    .update({
      phone: parsed.data.phone || null,
      email: parsed.data.email || null,
      avatar_url: parsed.data.avatar_url || null,
    })
    .eq("id", profile.id);

  if (error) return { error: "Could not update profile." };

  revalidatePath("/student/profile");
  return { success: true };
}

const changePinSchema = z.object({
  newPin: z.string().min(4, "PIN must be at least 4 digits").regex(/^[0-9]+$/, "PIN must be numeric"),
});

export async function changeOwnPinAction(newPin: string): Promise<ActionResult> {
  const profile = await requireProfile();
  const parsed = changePinSchema.safeParse({ newPin });
  if (!parsed.success) return { error: parsed.error.issues[0]?.message };

  const supabase = await createClient();
  const { error } = await supabase.auth.updateUser({ password: parsed.data.newPin });
  if (error) return { error: "Could not change PIN." };

  await logAudit({ actorId: profile.id, action: "profile.change_pin", entityType: "profile", entityId: profile.id });
  return { success: true };
}
