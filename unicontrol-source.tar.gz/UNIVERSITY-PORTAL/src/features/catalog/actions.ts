"use server";

import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { requireRole } from "@/lib/auth";
import { logAudit } from "@/lib/audit";
import { subjectSchema, teacherSchema } from "@/validators/schedule";

export interface ActionResult {
  error?: string;
  success?: boolean;
}

export async function createSubjectAction(_prev: ActionResult, formData: FormData): Promise<ActionResult> {
  const admin = await requireRole("admin");
  const parsed = subjectSchema.safeParse({ name: formData.get("name"), code: formData.get("code") });
  if (!parsed.success) return { error: parsed.error.issues[0]?.message };

  const supabase = await createClient();
  const { data, error } = await supabase.from("subjects").insert(parsed.data).select().single();
  if (error) return { error: error.code === "23505" ? "That subject code already exists." : "Could not create subject." };

  await logAudit({ actorId: admin.id, action: "subject.create", entityType: "subject", entityId: data.id, newData: data });
  revalidatePath("/admin/schedule");
  return { success: true };
}

export async function deleteSubjectAction(id: string): Promise<ActionResult> {
  const admin = await requireRole("admin");
  const supabase = await createClient();
  const { error } = await supabase.from("subjects").delete().eq("id", id);
  if (error) return { error: "Cannot delete a subject still used by schedules, sessions or assignments." };

  await logAudit({ actorId: admin.id, action: "subject.delete", entityType: "subject", entityId: id });
  revalidatePath("/admin/schedule");
  return { success: true };
}

export async function createTeacherAction(_prev: ActionResult, formData: FormData): Promise<ActionResult> {
  const admin = await requireRole("admin");
  const parsed = teacherSchema.safeParse({
    first_name: formData.get("first_name"),
    last_name: formData.get("last_name"),
    phone: formData.get("phone"),
    email: formData.get("email"),
  });
  if (!parsed.success) return { error: parsed.error.issues[0]?.message };

  const supabase = await createClient();
  const { data, error } = await supabase
    .from("teachers")
    .insert({
      first_name: parsed.data.first_name,
      last_name: parsed.data.last_name,
      phone: parsed.data.phone || null,
      email: parsed.data.email || null,
    })
    .select()
    .single();
  if (error) return { error: "Could not create teacher." };

  await logAudit({ actorId: admin.id, action: "teacher.create", entityType: "teacher", entityId: data.id, newData: data });
  revalidatePath("/admin/schedule");
  return { success: true };
}

export async function deleteTeacherAction(id: string): Promise<ActionResult> {
  const admin = await requireRole("admin");
  const supabase = await createClient();
  const { error } = await supabase.from("teachers").delete().eq("id", id);
  if (error) return { error: "Could not delete teacher." };

  await logAudit({ actorId: admin.id, action: "teacher.delete", entityType: "teacher", entityId: id });
  revalidatePath("/admin/schedule");
  return { success: true };
}
