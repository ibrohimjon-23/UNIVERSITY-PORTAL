"use server";

import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { requireRole } from "@/lib/auth";
import { logAudit } from "@/lib/audit";
import { notificationSchema } from "@/validators/notification";

export interface ActionResult {
  error?: string;
  success?: boolean;
}

export async function sendNotificationAction(_prev: ActionResult, formData: FormData): Promise<ActionResult> {
  const actor = await requireRole("admin", "leader");
  const parsed = notificationSchema.safeParse({
    title: formData.get("title"),
    message: formData.get("message"),
    type: formData.get("type") || "info",
    target_type: formData.get("target_type"),
    target_id: formData.get("target_id"),
  });

  if (!parsed.success) return { error: parsed.error.issues[0]?.message };

  if (actor.role === "leader") {
    if (!["group", "student"].includes(parsed.data.target_type)) {
      return { error: "Leaders can only notify their own group or a specific student." };
    }
    if (parsed.data.target_type === "group" && parsed.data.target_id !== actor.group_id) {
      return { error: "You can only notify your own group." };
    }
  }

  const supabase = await createClient();

  if (parsed.data.target_type === "student" && actor.role === "leader") {
    const { data: target } = await supabase.from("profiles").select("group_id").eq("id", parsed.data.target_id).maybeSingle();
    if (!target || target.group_id !== actor.group_id) {
      return { error: "You can only notify students in your own group." };
    }
  }

  const { data, error } = await supabase
    .from("notifications")
    .insert({
      title: parsed.data.title,
      message: parsed.data.message,
      type: parsed.data.type,
      sender_id: actor.id,
      target_type: parsed.data.target_type,
      target_id: parsed.data.target_id || null,
    })
    .select()
    .single();

  if (error) return { error: "Could not send notification." };

  await logAudit({
    actorId: actor.id,
    action: "notification.send",
    entityType: "notification",
    entityId: data.id,
    newData: data,
  });

  revalidatePath("/admin/notifications");
  revalidatePath("/leader/notifications");
  revalidatePath("/student/notifications");
  return { success: true };
}

export async function markNotificationReadAction(notificationId: string): Promise<ActionResult> {
  const supabase = await createClient();
  const { data: user } = await supabase.auth.getUser();
  if (!user.user) return { error: "Not authenticated." };

  const { error } = await supabase
    .from("notification_reads")
    .upsert({ notification_id: notificationId, user_id: user.user.id }, { onConflict: "notification_id,user_id" });

  if (error) return { error: "Could not mark as read." };
  return { success: true };
}

export async function deleteNotificationAction(notificationId: string): Promise<ActionResult> {
  const admin = await requireRole("admin");
  const supabase = await createClient();
  const { error } = await supabase.from("notifications").delete().eq("id", notificationId);
  if (error) return { error: "Could not delete notification." };

  await logAudit({ actorId: admin.id, action: "notification.delete", entityType: "notification", entityId: notificationId });
  revalidatePath("/admin/notifications");
  return { success: true };
}
