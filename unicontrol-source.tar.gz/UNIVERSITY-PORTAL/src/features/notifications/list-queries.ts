import "server-only";
import { createClient } from "@/lib/supabase/server";
import type { Notification, Profile } from "@/types/database";

export interface NotificationRow extends Notification {
  is_read: boolean;
  sender_name: string | null;
}

export async function listNotificationsForUser(profile: Profile, page = 1, pageSize = 15) {
  const supabase = await createClient();
  const from = (page - 1) * pageSize;
  const to = from + pageSize - 1;

  let query = supabase.from("notifications").select("*", { count: "exact" });

  if (profile.role === "admin") {
    // Admin sees everything via RLS.
  } else if (profile.role === "leader") {
    query = query.or(
      `target_type.eq.everyone,target_type.eq.all_leaders,and(target_type.eq.group,target_id.eq.${profile.group_id ?? "00000000-0000-0000-0000-000000000000"})`,
    );
  } else {
    query = query.or(
      `target_type.eq.everyone,target_type.eq.all_students,and(target_type.eq.group,target_id.eq.${profile.group_id ?? "00000000-0000-0000-0000-000000000000"}),and(target_type.eq.student,target_id.eq.${profile.id})`,
    );
  }

  const { data, count, error } = await query.order("created_at", { ascending: false }).range(from, to);
  if (error) throw error;

  const notifications = (data ?? []) as Notification[];
  const ids = notifications.map((n) => n.id);
  const senderIds = Array.from(new Set(notifications.map((n) => n.sender_id)));

  const [{ data: reads }, { data: senders }] = await Promise.all([
    ids.length
      ? supabase.from("notification_reads").select("notification_id").eq("user_id", profile.id).in("notification_id", ids)
      : Promise.resolve({ data: [] as { notification_id: string }[] }),
    senderIds.length
      ? supabase.from("profiles").select("id, first_name, last_name").in("id", senderIds)
      : Promise.resolve({ data: [] as Pick<Profile, "id" | "first_name" | "last_name">[] }),
  ]);

  const readSet = new Set((reads ?? []).map((r) => r.notification_id));
  const senderById = new Map((senders ?? []).map((s) => [s.id, `${s.first_name} ${s.last_name}`]));

  const rows: NotificationRow[] = notifications.map((n) => ({
    ...n,
    is_read: readSet.has(n.id),
    sender_name: senderById.get(n.sender_id) ?? null,
  }));

  return { rows, total: count ?? 0, page, pageSize };
}
