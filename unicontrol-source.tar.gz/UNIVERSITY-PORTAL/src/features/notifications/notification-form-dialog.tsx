"use client";

import { useActionState, useEffect, useRef, useState } from "react";
import { useFormStatus } from "react-dom";
import { useRouter } from "next/navigation";
import { Loader2, Plus } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogTrigger,
} from "@/components/ui/dialog";
import { sendNotificationAction, type ActionResult } from "@/features/notifications/actions";
import type { Group, NotificationTarget, Profile, UserRole } from "@/types/database";

const initial: ActionResult = {};

function SubmitButton() {
  const { pending } = useFormStatus();
  return (
    <Button type="submit" disabled={pending}>
      {pending ? <Loader2 className="h-4 w-4 animate-spin" /> : null}
      Send
    </Button>
  );
}

interface NotificationFormDialogProps {
  role: UserRole;
  groups: Group[];
  students: Profile[];
  lockedGroupId?: string;
}

export function NotificationFormDialog({ role, groups, students, lockedGroupId }: NotificationFormDialogProps) {
  const [state, formAction] = useActionState(sendNotificationAction, initial);
  const [open, setOpen] = useState(false);
  const [targetType, setTargetType] = useState<NotificationTarget>(role === "leader" ? "group" : "everyone");
  const [targetId, setTargetId] = useState(lockedGroupId ?? "");
  const router = useRouter();
  const formRef = useRef<HTMLFormElement>(null);

  useEffect(() => {
    if (state.success) {
      toast.success("Notification sent");
      setOpen(false);
      formRef.current?.reset();
      router.refresh();
    } else if (state.error) toast.error(state.error);
  }, [state, router]);

  const targetOptions: { value: NotificationTarget; label: string }[] =
    role === "admin"
      ? [
          { value: "everyone", label: "Everyone" },
          { value: "all_leaders", label: "All leaders" },
          { value: "all_students", label: "All students" },
          { value: "group", label: "Specific group" },
          { value: "student", label: "Specific student" },
        ]
      : [
          { value: "group", label: "My group" },
          { value: "student", label: "Specific student" },
        ];

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button>
          <Plus className="h-4 w-4" />
          Send notification
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Send notification</DialogTitle>
        </DialogHeader>
        <form ref={formRef} action={formAction} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="title">Title</Label>
            <Input id="title" name="title" required />
          </div>
          <div className="space-y-2">
            <Label htmlFor="message">Message</Label>
            <Textarea id="message" name="message" required rows={4} />
          </div>
          <div className="space-y-2">
            <Label>Type</Label>
            <Select name="type" defaultValue="info">
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="info">Info</SelectItem>
                <SelectItem value="success">Success</SelectItem>
                <SelectItem value="warning">Warning</SelectItem>
                <SelectItem value="urgent">Urgent</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label>Send to</Label>
            <input type="hidden" name="target_type" value={targetType} />
            <Select
              value={targetType}
              onValueChange={(v) => {
                setTargetType(v as NotificationTarget);
                setTargetId(v === "group" ? (lockedGroupId ?? "") : "");
              }}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {targetOptions.map((opt) => (
                  <SelectItem key={opt.value} value={opt.value}>
                    {opt.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          {targetType === "group" && role === "admin" ? (
            <div className="space-y-2">
              <Label>Group</Label>
              <input type="hidden" name="target_id" value={targetId} />
              <Select value={targetId} onValueChange={setTargetId}>
                <SelectTrigger>
                  <SelectValue placeholder="Select a group" />
                </SelectTrigger>
                <SelectContent>
                  {groups.map((g) => (
                    <SelectItem key={g.id} value={g.id}>
                      {g.group_name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          ) : null}
          {targetType === "student" ? (
            <div className="space-y-2">
              <Label>Student</Label>
              <input type="hidden" name="target_id" value={targetId} />
              <Select value={targetId} onValueChange={setTargetId}>
                <SelectTrigger>
                  <SelectValue placeholder="Select a student" />
                </SelectTrigger>
                <SelectContent>
                  {students.map((s) => (
                    <SelectItem key={s.id} value={s.id}>
                      {s.first_name} {s.last_name} (@{s.username})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          ) : null}
          {targetType === "group" && role === "leader" ? <input type="hidden" name="target_id" value={lockedGroupId} /> : null}
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => setOpen(false)}>
              Cancel
            </Button>
            <SubmitButton />
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
