import "server-only";
import { createClient } from "@/lib/supabase/server";

export interface AdminDashboardStats {
  total_students: number;
  total_groups: number;
  total_leaders: number;
  today_present: number;
  today_late: number;
  today_excused: number;
  today_absent: number;
  active_assignments: number;
  unread_notifications: number;
}

export async function getAdminDashboardStats(): Promise<AdminDashboardStats> {
  const supabase = await createClient();
  const { data, error } = await supabase.rpc("fn_admin_dashboard_stats");
  if (error) throw error;
  return data as AdminDashboardStats;
}

export interface LeaderDashboardStats {
  total_students: number;
  today_present: number;
  today_late: number;
  today_excused: number;
  today_absent: number;
  active_assignments: number;
  unread_notifications: number;
}

export async function getLeaderDashboardStats(): Promise<LeaderDashboardStats> {
  const supabase = await createClient();
  const { data, error } = await supabase.rpc("fn_leader_dashboard_stats");
  if (error) throw error;
  return data as LeaderDashboardStats;
}

export interface AttendanceTrendPoint {
  day: string;
  present: number;
  late: number;
  absent: number;
  excused: number;
}

export async function getAttendanceTrend(days = 14): Promise<AttendanceTrendPoint[]> {
  const supabase = await createClient();
  const { data, error } = await supabase.rpc("fn_attendance_trend", { p_days: days });
  if (error) throw error;
  return (data ?? []) as AttendanceTrendPoint[];
}
